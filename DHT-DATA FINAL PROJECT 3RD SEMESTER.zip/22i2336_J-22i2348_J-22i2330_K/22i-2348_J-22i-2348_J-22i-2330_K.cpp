#include <iostream>
#include <string>
#include <windows.h>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <list>
#include <direct.h>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

class Machine;

int machineCount = 0;
int identifier_space = 0;
int order = 0;

const string white_colour = "\033[0m", light_blue_colour = "\033[1;94m", blue_colour = "\033[0;36m", red_colour = "\033[1;31m", green_colour = "\033[1;92m", ladoo_peela_colour = "\033[0;33m";

int integer_input_validation(int choice, int first_option, int last_option)
{
    while (!(cin >> choice) || choice > last_option || choice < first_option)
    {
        cout << red_colour << "\n\tInvalid input. Enter again: " << white_colour;
        cin.clear();
        cin.ignore(100, '\n');
    }
    return choice;
}

string string_input_validation(string machine_name)
{
    getline(cin, machine_name);
    int check = count(machine_name.begin(), machine_name.end(), ' ');
    while (check > 0 || machine_name.empty())
    {
        if (machine_name.empty())
        {
            cout << red_colour << "\n\tInvalid input: cannot be empty. Enter again: " << white_colour;
        }
        else
        {
            cout << red_colour << "\n\tInvalid input: cannot have spaces. Enter again: " << white_colour;
        }
        getline(cin, machine_name);
        check = count(machine_name.begin(), machine_name.end(), ' ');
    }

    return machine_name;
}
///so this function would return a string name 
string AutomaticallyGenerateNameOfMachine() {//we will use this function only where we were previously asking user for name of machine//here this function generates a random string //aagey waala saara kaam after taking string name_of_machine input would remain same //as we did in manually assigning machine ids

    const int name_length = 10;//this tells how long will the auto name be
    const std::string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";//this is for in letters kilibrary mn sey choose
    srand(time(0));//ye bas karna hota hey
    std::string random_name;
    random_name.reserve(name_length);
    for (int i = 0; i < name_length; ++i) {
        random_name += chars[rand() % chars.size()];//random chars ;)
    }

    return random_name;
}

bool copyFile(const string& source_path, const string& destination_path)
{
    ifstream source_file(source_path);
    ofstream destination_file(destination_path);

    if (!source_file || !destination_file)
    {
        return 0;
    }

    destination_file << source_file.rdbuf();

    source_file.close();
    destination_file.close();

    return 1;
}

class btreeNode
{
    uint64_t* keys;// array of keys
    int t;    // the range of the numbers of the key
    string file_path;
    string file_name;
    int mapped_id;
    btreeNode** c; // array of child pointers
    int n;    // variable to check the num of keys;
    bool leaf; // true if node is leaf
    list<int> overflowList; // ll to handle overflow

public:
    string get_name()
    {
        return file_name;
    }
    string get_path()
    {
        return file_path;
    }
    btreeNode(int _t, bool _leaf);

    void traverse();
    btreeNode* search(uint64_t k);// file path add karna hai
    int findkey(uint64_t k);
    void insertnonfull(uint64_t k);
    void splitchild(int i, btreeNode* y);

    void remove(uint64_t k); // file path
    void removefromleaf(int idx);
    void removefromnonleaf(int idx);
    int getpred(int idx); // predecessor
    int getsucc(int idx); // successor
    void fill(int idx);
    void borrowfromprev(int idx);
    void borrowfromnext(int idx);
    void merge(int idx);

    void give_files_to_next_machine(int next_machine_mapped_id, Machine* next_machine); //call when delete a machine
    void distribute_files(Machine* one_ahead_of_new_machine, Machine* new_machine); //use in the function where creating machine

    friend class btree;
};
class btree
{
    btreeNode* root;
    int t;

public:

    btree(int _t) {
        root = nullptr;
        t = _t;
    }

    void traverse()
    {
        if (root != NULL)
        {
            root->traverse();
        }
    }

    btreeNode* search(uint64_t k)
    {
        return ((root == NULL) ? NULL : root->search(k));
    }

    void insert(uint64_t k, int map_id, string f_name, string f_path);
    void remove(uint64_t k);

    void give_files_to_next_machine(int mapped_id_of_next, Machine* next_machine)
    {
        if (root != nullptr)
        {
            root->give_files_to_next_machine(mapped_id_of_next, next_machine);
        }
        else
        {
            cout << "No files to transfer/distribute.\n";
        }
    }

    void distribute_files(Machine* one_ahead_in_ring, Machine* new_machine)
    {
        if (root != nullptr)
        {
            root->distribute_files(one_ahead_in_ring, new_machine);
        }
        else
        {
            cout << "No files to transfer/distribute.\n";
        }
    }
};
btreeNode::btreeNode(int t1, bool leaf1) {
    t = t1; // given minimum  degree//set by user too
    leaf = leaf1;
    keys = new uint64_t[2 * t - 1];
    c = new btreeNode * [2 * t];
    n = 0; // keys
    file_name = " ";
    file_path = " ";
}
int btreeNode::findkey(uint64_t k) {
    int idx = 0;
    while (idx < n && (keys[idx] < k || (keys[idx] == k && file_path < file_path)))
        ++idx;
    return idx;
}

void btreeNode::remove(uint64_t k) {
    int idx = findkey(k);
    if (idx < n && keys[idx] == k) {
        if (leaf) {
            removefromleaf(idx);
        }
        else {
            removefromnonleaf(idx);
        }
    }
    else {
        if (leaf) {
            return;
        }
        bool flag = ((idx == n) ? true : false);
        if (c[idx]->n < t) {
            fill(idx);
        }

        if (flag && idx > n) {
            c[idx - 1]->remove(k);
        }
        else {
            c[idx]->remove(k);
        }
    }
    return;
}

void btreeNode::removefromleaf(int idx) {
    for (int j = idx + 1; j < n; ++j) {
        keys[j - 1] = keys[j];
    }
    n--;

    // chaining
    if (n < t - 1 && !overflowList.empty()) {
        int lastOverflow = overflowList.back();
        overflowList.pop_back();
        keys[n] = lastOverflow;
        n++;
    }

    return;
}

void btreeNode::removefromnonleaf(int idx) {
    int k = keys[idx];

    if (c[idx]->n >= t) {
        int pred = getpred(idx);
        keys[idx] = pred;
        c[idx]->remove(pred);
    }
    else if (c[idx + 1]->n >= t) {
        int succ = getsucc(idx);
        keys[idx] = succ;
        c[idx + 1]->remove(succ);
    }
    else {
        merge(idx);
        c[idx]->remove(k);
    }

    // chaining
    if (n < t - 1 && !overflowList.empty()) {
        int lastOverflow = overflowList.back();
        overflowList.pop_back();
        keys[n] = lastOverflow;
        n++;
    }

    return;
}

int btreeNode::getpred(int idx) {
    btreeNode* cur = c[idx];
    while (!cur->leaf)
        cur = cur->c[cur->n];
    return cur->keys[cur->n - 1];
}

int btreeNode::getsucc(int idx) {
    btreeNode* cur = c[idx + 1];
    while (!cur->leaf)
        cur = cur->c[0];
    return cur->keys[0];
}

void btreeNode::fill(int idx) {
    if (idx != 0 && c[idx - 1]->n >= t) {
        borrowfromprev(idx);
    }
    else if (idx != n && c[idx + 1]->n >= t) {
        borrowfromnext(idx);
    }
    else {
        if (idx != n) {
            merge(idx);
        }
        else {
            merge(idx - 1);
        }
    }
    return;
}

void btreeNode::borrowfromprev(int idx) {
    btreeNode* child = c[idx];
    btreeNode* sibling = c[idx - 1];

    for (int i = child->n - 1; i >= 0; --i) {
        child->keys[i + 1] = child->keys[i];
    }

    if (!child->leaf) {
        for (int i = child->n; i >= 0; --i) {
            child->c[i + 1] = child->c[i];
        }
    }

    child->keys[0] = keys[idx - 1];

    if (!child->leaf) {
        child->c[0] = sibling->c[sibling->n];
        keys[idx - 1] = sibling->keys[sibling->n - 1];
        child->n += 1;
        sibling->n -= 1;
    }

    // chaining
    if (sibling->n < t - 1 && !sibling->overflowList.empty()) {
        int lastOverflow = sibling->overflowList.back();
        sibling->overflowList.pop_back();
        sibling->keys[sibling->n] = lastOverflow;
        sibling->n++;
    }

    return;
}

void btreeNode::borrowfromnext(int idx) {
    btreeNode* child = c[idx];
    btreeNode* sibling = c[idx + 1];

    child->keys[(child->n)] = keys[idx];

    if (!child->leaf) {
        child->c[(child->n) + 1] = sibling->c[0];
    }

    keys[idx] = sibling->keys[0];

    for (int j = 1; j < sibling->n; ++j) {
        sibling->keys[j - 1] = sibling->keys[j];
    }

    if (!sibling->leaf) {
        for (int j = 1; j <= sibling->n; ++j) {
            sibling->c[j - 1] = sibling->c[j];
        }
    }

    child->n++;
    sibling->n--;

    // chaining
    if (sibling->n < t - 1 && !sibling->overflowList.empty()) {
        int firstOverflow = sibling->overflowList.front();
        sibling->overflowList.pop_front();
        sibling->keys[sibling->n] = firstOverflow;
        sibling->n++;
    }

    return;
}

void btreeNode::merge(int idx) {
    btreeNode* child = c[idx];
    btreeNode* sibling = c[idx + 1];

    child->keys[t - 1] = keys[idx];

    for (int j = 0; j < sibling->n; ++j) {
        child->keys[j + t] = sibling->keys[j];
    }

    if (!child->leaf) {
        for (int j = 0; j <= sibling->n; ++j) {
            child->c[j + t] = sibling->c[j];
        }
    }

    for (int i = idx + 1; i < n; ++i) {
        keys[i - 1] = keys[i];
    }

    for (int j = idx + 2; j <= n; ++j) {
        c[j - 1] = c[j];
    }

    child->n += sibling->n + 1;
    n--;

    delete (sibling);

    // chaining
    if (n < t - 1 && !overflowList.empty()) {
        int lastOverflow = overflowList.back();
        overflowList.pop_back();
        keys[n] = lastOverflow;
        n++;
    }

    return;
}

void btree::remove(uint64_t k) {
    if (!root) {
        cout << "\nBTree is empty.\n";
        return;
    }
    root->remove(k);

    // chaining
    if (root->n == 0) {
        btreeNode* temp = root;
        if (root->leaf) {
            root = NULL;
        }
        else {
            root = root->c[0];
            delete temp;
        }
    }
    return;
}

void btreeNode::traverse()
{
    int i;
    for (i = 0; i < n; i++)
    {
        if (leaf == false)
            c[i]->traverse();
        cout << " " << keys[i] << endl;

    }

    if (leaf == false)
    {
        cout << " " << keys[i] << endl;
    }
}

btreeNode* btreeNode::search(uint64_t k) {
    int i = 0;

    while (i < n && k > keys[i]) {
        i++;
    }

    if (keys[i] == k) {
        return this;
    }

    if (leaf == true) {
        return NULL;
    }
    else {
        return c[i]->search(k);
    }
}

void btree::insert(uint64_t k, int map_id, string f_name, string f_path)
{
    if (root == nullptr) {
        root = new btreeNode(t, true);
        root->keys[0] = k; //key
        root->n = 1;
        root->mapped_id = map_id;
        root->file_name = f_name;
        root->file_path = f_path;

    }
    else {
        if (root->n == 2 * t - 1) {
            btreeNode* s = new btreeNode(t, false);
            s->c[0] = root;
            s->splitchild(0, root);
            root->mapped_id = map_id;
            root->file_name = f_name;
            root->file_path = f_path;
            int i = 0;

            if (s->keys[0] < k) {
                i++;
            }

            s->c[i]->insertnonfull(k);
            root = s;
        }
        else {
            root->insertnonfull(k);
        }
    }
}

void btreeNode::insertnonfull(uint64_t k)
{
    int i = n - 1;

    if (leaf) {
        while (i >= 0 && k < keys[i]) {
            keys[i + 1] = keys[i];
            i--;
        }

        keys[i + 1] = k;
        n++;
    }
    else {
        while (i >= 0 && k < keys[i]) {
            i--;
        }

        if (c[i + 1]->n == 2 * t - 1) {
            splitchild(i + 1, c[i + 1]);

            if (k > keys[i + 1]) {
                i++;
            }
        }

        c[i + 1]->insertnonfull(k);
    }
}

void btreeNode::splitchild(int i, btreeNode* y) {
    btreeNode* z = new btreeNode(y->t, y->leaf);
    z->n = t - 1;

    for (int j = 0; j < t - 1; j++) {
        z->keys[j] = y->keys[j + t];
    }

    if (!y->leaf) {
        for (int j = 0; j < t; j++) {
            z->c[j] = y->c[j + t];
        }
    }

    y->n = t - 1;

    for (int j = n; j > i; j--) {
        c[j + 1] = c[j];
    }

    c[i + 1] = z;

    for (int j = n - 1; j >= i; j--) {
        keys[j + 1] = keys[j];
    }

    keys[i] = y->keys[t - 1];
    n++;
}

constexpr uint64_t combineHashValues(uint32_t h0, uint32_t h1, uint32_t h2, uint32_t h3, uint32_t h4)
{
    return static_cast<uint64_t>(h0) << 32 |
        static_cast<uint64_t>(h1) << 32 |
        static_cast<uint64_t>(h2) << 32 |
        static_cast<uint64_t>(h3) << 32 |
        static_cast<uint64_t>(h4);
}
constexpr uint32_t leftRotate(uint32_t v, int shi)
{
    return (v << shi) | (v >> (32 - shi));
}
uint64_t generateSHA1Hash1(const string& input) //sha1 for files
{
    // Initialize constants
    const uint32_t K[] =
    {
        0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xCA62C1D6
    };
    // Initialize variables
    uint32_t h0 = 0x67452301;
    uint32_t h1 = 0xEFCDAB89;
    uint32_t h2 = 0x98BADCFE;
    uint32_t h3 = 0x10325476;
    uint32_t h4 = 0xC3D2E1F0;
    // Pad the message
    string paddedMessage = input;
    // Append a single '1' bit
    paddedMessage += static_cast<char>(0x80);
    // Calculate the padding
    size_t originalLength = input.length();
    size_t newLength = paddedMessage.length();
    size_t bitLength = originalLength * 8;
    // Append '0' bits until the message is padded to 64 bits less than a multiple of 512
    while ((newLength + 8) % 64 != 0) {
        paddedMessage += static_cast<char>(0x00);
        newLength++;
    }
    // Append the original length of the message as an 64-bit integer (in big-endian order)
    for (int i = 7; i >= 0; --i)
    {
        paddedMessage += static_cast<char>((bitLength >> (i * 8)) & 0xFF);
    }
    // Process the message in 512-bit blocks
    for (size_t i = 0; i < newLength; i += 64) {
        uint32_t w[80];
        // Break the block into sixteen 32-bit big-endian words
        for (int j = 0; j < 16; j++) {
            w[j] = (paddedMessage[i + j * 4] << 24) |
                (paddedMessage[i + j * 4 + 1] << 16) |
                (paddedMessage[i + j * 4 + 2] << 8) |
                (paddedMessage[i + j * 4 + 3]);
        }
        // Extend the sixteen 32-bit words into eighty 32-bit words
        for (int j = 16; j < 80; j++) {
            w[j] = leftRotate(w[j - 3] ^ w[j - 8] ^ w[j - 14] ^ w[j - 16], 1);
        }
        // Initialize hash value for this chunk
        uint32_t a = h0;
        uint32_t b = h1;
        uint32_t c = h2;
        uint32_t d = h3;
        uint32_t e = h4;
        // Main loop
        for (int j = 0; j < 80; j++)
        {
            uint32_t f, k;

            if (j < 20)
            {
                f = (b & c) | ((~b) & d);
                k = K[0];
            }
            else if (j < 40)
            {
                f = b ^ c ^ d;
                k = K[1];
            }
            else if (j < 60)
            {
                f = (b & c) | (b & d) | (c & d);
                k = K[2];
            }
            else
            {
                f = b ^ c ^ d;
                k = K[3];
            }
            uint32_t temp = leftRotate(a, 5) + f + e + k + w[j];
            e = d;
            d = c;
            c = leftRotate(b, 30);
            b = a;
            a = temp;
        }
        // Add this chunk's hash to result so far
        h0 += a;
        h1 += b;
        h2 += c;
        h3 += d;
        h4 += e;
    }
    // Produce the final hash as a string of 40 hexadecimal character
    return combineHashValues(h0, h1, h2, h3, h4);
}
string generateSHA1Hash(const string& input)
{
    // Initialize constants
    const uint32_t K[] = { 0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xCA62C1D6 };

    // Initialize variables
    uint32_t h0 = 0x67452301;
    uint32_t h1 = 0xEFCDAB89;
    uint32_t h2 = 0x98BADCFE;
    uint32_t h3 = 0x10325476;
    uint32_t h4 = 0xC3D2E1F0;

    // Pad the message
    string paddedMessage = input;

    // Append a single '1' bit
    paddedMessage += static_cast<char>(0x80);

    // Calculate the padding
    size_t originalLength = input.length();
    size_t newLength = paddedMessage.length();
    size_t bitLength = originalLength * 8;

    // Append '0' bits until the message is padded to 64 bits less than a multiple of 512
    while ((newLength + 8) % 64 != 0)
    {
        paddedMessage += static_cast<char>(0x00);
        newLength++;
    }

    // Append the original length of the message as an 64-bit integer (in big-endian order)
    for (int i = 7; i >= 0; --i)
    {
        paddedMessage += static_cast<char>((bitLength >> (i * 8)) & 0xFF);
    }

    // Process the message in 512-bit blocks
    for (size_t i = 0; i < newLength; i += 64)
    {
        uint32_t w[80];
        // Break the block into sixteen 32-bit big-endian words
        for (int j = 0; j < 16; j++)
        {
            w[j] = (paddedMessage[i + j * 4] << 24) | (paddedMessage[i + j * 4 + 1] << 16) | (paddedMessage[i + j * 4 + 2] << 8) | (paddedMessage[i + j * 4 + 3]);
        }
        for (int j = 16; j < 80; j++)
        {
            w[j] = leftRotate(w[j - 3] ^ w[j - 8] ^ w[j - 14] ^ w[j - 16], 1);
        }
        // Initialize hash v for this chunk
        uint32_t a = h0;
        uint32_t b = h1;
        uint32_t c = h2;
        uint32_t d = h3;
        uint32_t e = h4;
        // Main loop
        for (int j = 0; j < 80; j++)
        {
            uint32_t f, k;
            if (j < 20)
            {
                f = (b & c) | ((~b) & d);
                k = K[0];
            }
            else if (j < 40)
            {
                f = b ^ c ^ d;
                k = K[1];
            }
            else if (j < 60)
            {
                f = (b & c) | (b & d) | (c & d);
                k = K[2];
            }
            else
            {
                f = b ^ c ^ d;
                k = K[3];
            }
            uint32_t temp = leftRotate(a, 5) + f + e + k + w[j];
            e = d;
            d = c;
            c = leftRotate(b, 30);
            b = a;
            a = temp;
        }
        // Add this chunk's hash to result so far
        h0 += a;
        h1 += b;
        h2 += c;
        h3 += d;
        h4 += e;
    }

    // Produce the final hash as a string of 40 hexadecimal characters
    stringstream ss;
    ss << hex << setw(8) << setfill('0') << h0 << setw(8) << setfill('0') << h1 << setw(8) << setfill('0') << h2 << setw(8) << setfill('0') << h3 << setw(8) << setfill('0') << h4;

    return ss.str();
}

class FingerTable;
class Machine
{
public: //turn private 
    string machinename; //hash_id generated thru this
    string m_hash_id;
    Machine* next_machine;
    int mapped_ID_within_identifier_Space;//NABZ //SHA-1 produces a very long string ID but to give ID,s to machine we need id,s less than 2^m identifier space so hum koi na koi formula kar k ye aik simple id generate kara rahey hen within mod of 2^m
    FingerTable* headOfFingerTable;//NABZ
    int SuccessorId;//NABZ
    int PredecessorId;//NABZ
    //  Machine* prev_machine; //for maintaining a doubly linked list for DHT //also the range of a machine would be inclusive of it,s own [currNode->id and exclsuive of previous Node,s ->currID) //and inclusive of all the values between these two nodes
    btree* head_of_files;

    Machine(int hash)
    {
        machinename = "";
        mapped_ID_within_identifier_Space = hash;//NABZ
        next_machine = nullptr;
        SuccessorId = -1;//NABZ
        PredecessorId = -1;//NABZ
        //headOfFingerTable->FPi = -1;
       // headOfFingerTable->shortCutPtr = nullptr;
        head_of_files = new btree(order);
    }
    Machine(string machine_name, string machine_hash, int mapped_id)
    {
        mapped_ID_within_identifier_Space = mapped_id;
        machinename = machine_name;
        m_hash_id = machine_hash;
        next_machine = nullptr;
        head_of_files = new btree(order);
    }
    Machine()
    {
        machinename = "";
        m_hash_id = "";
        next_machine = nullptr;
        mapped_ID_within_identifier_Space = 0;
        headOfFingerTable = nullptr;
        SuccessorId = 0;
        PredecessorId = 0;
        head_of_files = new btree(order);
    }
    Machine(string machine_name, string machine_hash)
    {
        machinename = machine_name;
        m_hash_id = machine_hash;
        next_machine = nullptr;
        head_of_files = new btree(order);
    }
    string sha1_get_hash_id()
    {
        return m_hash_id;
    }
    int get_hash_id()
    {
        return mapped_ID_within_identifier_Space;//NABZ
    }
    void set_next_machine(Machine* machine)
    {
        next_machine = machine;
    }
    Machine* get_next_machine()
    {
        return next_machine;
    }
    string get_machine_name()
    {
        return machinename;
    }
};

void btreeNode::give_files_to_next_machine(int next_machine_mapped_id, Machine* next_machine) //call when delete a machine
{
    int i;
    for (i = 0; i < n; i++)
    {
        if (leaf == false)
            c[i]->traverse();
        next_machine->head_of_files->insert(keys[i], mapped_id, file_name, file_path);
        string folder_path = "C:/Users/mahaq/OneDrive/Desktop/dsa/FinalProject/FinalProject/Machine #" + to_string(next_machine_mapped_id);
        string source = file_path;
        string destination = folder_path + "/" + file_name;
        ofstream createfile(file_name, ios::app);
        createfile.close();
        if (!copyFile(source, destination))
        {
            cout << "File does not exist." << endl;
        }
        else
        {
            cout << "File copied into the folder successfully!\n";
        }
    }

    if (leaf == false)
    {
        c[i]->traverse();
        next_machine->head_of_files->insert(keys[i], mapped_id, file_name, file_path);
        string folder_path = "C:/Users/mahaq/OneDrive/Desktop/dsa/FinalProject/FinalProject/Machine #" + to_string(next_machine_mapped_id);
        string source = file_path;
        string destination = folder_path + "/" + file_name;
        ofstream createfile(file_name, ios::app);
        createfile.close();
        if (!copyFile(source, destination))
        {
            cout << "File does not exist." << endl;
        }
        else
        {
            cout << "File copied into the folder successfully!\n";
        }
    }
}

void btreeNode::distribute_files(Machine* one_ahead_of_new_machine, Machine* new_machine) //use in the function where creating machine
{
    int i;
    for (i = 0; i < n; i++)
    {
        if (leaf == false)
            c[i]->traverse();
        if (mapped_id <= new_machine->mapped_ID_within_identifier_Space) //check if equal to new machine's mapped id or lesser, then put those files in new machine's btree
        {
            new_machine->head_of_files->insert(keys[i], mapped_id, file_name, file_path);
            remove(keys[i]);
            string folder_path = "C:/Users/mahaq/OneDrive/Desktop/dsa/FinalProject/FinalProject/Machine #" + to_string(new_machine->mapped_ID_within_identifier_Space);
            string source = file_path;
            string destination = folder_path + "/" + file_name;
            ofstream createfile(file_name, ios::app);
            createfile.close();
            if (!copyFile(source, destination))
            {
                cout << "File does not exist." << endl;
            }
            else
            {
                cout << "File copied into the folder successfully!\n";
            }

            //now remove from 1ahead folder

            folder_path = "C:/Users/mahaq/OneDrive/Desktop/dsa/FinalProject/FinalProject/Machine #" + to_string(one_ahead_of_new_machine->mapped_ID_within_identifier_Space);
            source = folder_path + "/" + file_name;

            if (::remove(source.c_str()) != 0)
            {
                cout << "File does not exist." << endl;
            }
            else
            {
                cout << "File removed successfully!" << endl;
            }
        }
    }

    if (leaf == false)
    {
        c[i]->traverse();
        if (mapped_id <= new_machine->mapped_ID_within_identifier_Space) //check if equal to new machine's mapped id or lesser, then put those files in new machine's btree
        {
            new_machine->head_of_files->insert(keys[i], mapped_id, file_name, file_path);
            remove(keys[i]);
            string folder_path = "C:/Users/mahaq/OneDrive/Desktop/dsa/FinalProject/FinalProject/Machine #" + to_string(new_machine->mapped_ID_within_identifier_Space);
            string source = file_path;
            string destination = folder_path + "/" + file_name;
            ofstream createfile(file_name, ios::app);
            createfile.close();
            if (!copyFile(source, destination))
            {
                cout << "File does not exist." << endl;
            }
            else
            {
                cout << "File copied into the folder successfully!\n";
            }

            //now remove from 1ahead folder

            folder_path = "C:/Users/mahaq/OneDrive/Desktop/dsa/FinalProject/FinalProject/Machine #" + to_string(one_ahead_of_new_machine->mapped_ID_within_identifier_Space);
            source = folder_path + "/" + file_name;

            if (::remove(source.c_str()) != 0)
            {
                cout << "File does not exist." << endl;
            }
            else
            {
                cout << "File removed successfully!" << endl;
            }
        }
    }
}

bool is_mapped_id_used(Machine* start_of_ring, int mapped_id) {
    Machine* current = start_of_ring;
    if (!current) {
        return false;
    }
    do {
        if (current->mapped_ID_within_identifier_Space == mapped_id) {
            return true;
        }
        current = current->get_next_machine();
    } while (current != start_of_ring);
    return false;
}

int mapped_id_for_machine_generator(Machine* start_of_ring, const string& hash_id, int identifier_space_bits) {
    //ye 2 ki power mn kar leta hey left rotation COAL 
    int identifier_space_size = 1 << identifier_space_bits;
    unsigned long hash_value = std::stoul(hash_id.substr(hash_id.length() - max(1, (identifier_space_bits + 3) / 4)), nullptr, 16);
    //take mod to decrease the mapped id to identifier space size
    int mapped_id = hash_value % identifier_space_size;
    //so here is basically a bool check that would traverse our ring dht to see if we have any duplicate mapped id if so make it unique 
    while (is_mapped_id_used(start_of_ring, mapped_id)) {
        mapped_id = (mapped_id + 1) % identifier_space_size; // Linear probing to find a unique ID
    }
    return mapped_id;
}

int mapped_id_for_machine_generator_for_file(const string& hash_id, int identifier_space_bits) {
    //ye 2 ki power mn kar leta hey left rotation COAL
    int identifier_space_size = 1 << identifier_space_bits;
    //take mod to decrease the mapped id to identifier space size
    unsigned long hash_value = std::stoul(hash_id.substr(hash_id.length() - max(1, (identifier_space_bits + 3) / 4)), nullptr, 16);
    int mapped_id = hash_value % identifier_space_size;
    return mapped_id;
}

Machine* create_machine(Machine* start_of_ring)
{
    int choice = 0;
    string machine_name = "";
    cout << "\tPress 1 to Manually assign ID\n";
    cout << "\tPress 2 to Automatically assign ID\n";
    cout << "\tYour choice: ";
    choice = integer_input_validation(choice, 1, 2);
    switch (choice)
    {
    case 1:
    {
        cin.ignore();
        cout << "Enter name of the machine: ";
        machine_name = string_input_validation(machine_name);
        break;
    }
    case 2:
    {
        machine_name = AutomaticallyGenerateNameOfMachine();
        break;
    }
    }
    string hash_id = generateSHA1Hash(machine_name);
    int mapped_id = mapped_id_for_machine_generator(start_of_ring, hash_id, identifier_space);

    cout << "SHA-1 hash ID: " << hash_id << "\nMapped hash ID: " << mapped_id << endl;

    string m = "Machine #"; //creation of folder part here
    string name_of_folder = m + to_string(mapped_id); //e.g. folder name will be Machine #1 where 1 is the mapped id (hash id mod with identifier space)
    _mkdir(name_of_folder.c_str());

    Machine* temp = new Machine(machine_name, hash_id, mapped_id);

    return temp;
}

class FingerTable {
public:
    int FPi;
    Machine* shortCutPtr;
};

bool search_machine(Machine* start_of_ring, Machine* machine_to_search)
{
    if (start_of_ring == nullptr)
    {
        return 0;
    }
    Machine* current = start_of_ring;
    do
    {
        if (current->get_hash_id() == machine_to_search->get_hash_id())
        {
            return 1;
        }
        current = current->get_next_machine();
    } while (current != start_of_ring);
    return 0;
}

void update_successor_and_predecessor_ids(Machine* head)                  //NABZ 
{
    if (head == nullptr || head->get_next_machine() == head)
    {

        return;
    }
    Machine* current = head;
    do {
        Machine* next_machine = current->get_next_machine();
        next_machine->PredecessorId = current->mapped_ID_within_identifier_Space;//PREDESECCOR ->CURRENT ->PREVIOUSID  
        current->SuccessorId = next_machine->mapped_ID_within_identifier_Space; //SUCCESSOR->CURRENT->NEXTID
        current = next_machine;
    } while (current != head);
}
Machine* find_machine_successor(Machine* start_of_ring, int FPi) {
    if (start_of_ring == nullptr) {
        return nullptr;//empty ring dht 
    }
    Machine* current = start_of_ring;
    Machine* successor = start_of_ring;

    do {
        if (current->get_hash_id() >= FPi) {
            // found the machine that has a hash_id greater than or equal to FPi
            successor = current;
            break;
        }
        current = current->get_next_machine();
    } while (current != start_of_ring);

    return successor;
}
void update_finger_table_for_machine(Machine* machine, int identifier_space, Machine* start_of_ring) {
    if (machine->headOfFingerTable == nullptr) {
        machine->headOfFingerTable = new FingerTable[identifier_space];
    }
    for (int i = 0; i < identifier_space; ++i) {
        //rotation 2 ki power mn multiplies
        unsigned int shift_amount = (1u << i) % (1u << identifier_space);//here using the formula as given in project doc p+(2powerI)-1 mod identifier space
        int FPi = (machine->get_hash_id() + shift_amount) % (1u << identifier_space);
        machine->headOfFingerTable[i].FPi = FPi;
        machine->headOfFingerTable[i].shortCutPtr = find_machine_successor(start_of_ring, FPi);//find machine succesoor finds that FPi kis machine ki range mn aata hey
    }
}
void initialize_finger_table(Machine* start_of_ring, int identifier_space) {
    Machine* current = start_of_ring;
    if (current == nullptr) return;

    do {
        if (current->headOfFingerTable != nullptr)
        {
            delete[] current->headOfFingerTable;//pichla delete to agla add
        }
        current->headOfFingerTable = new FingerTable[identifier_space]; // Allocate finger table

        for (int i = 0; i < identifier_space; ++i) {
            int FPi = (current->get_hash_id() + (1 << i)) % (1 << identifier_space); // Calculate FPi //THE MODULO OPERATOR FOR 2^IDENTIFIER SPACE MAKES SURE THE FPI IS WITHIN IDENTIFIER SPACE RANGE
            current->headOfFingerTable[i].FPi = FPi;

            // Find the successor machine for FPi
            Machine* successor = find_machine_successor(start_of_ring, FPi);
            current->headOfFingerTable[i].shortCutPtr = successor;
        }

        current = current->get_next_machine();
    } while (current != start_of_ring);
}
void update_all_finger_tables(Machine* start_of_ring, int identifier_space) {//dobara sey re-calculate the finger tables of all machines needed after insertion /removal of machines
    Machine* current = start_of_ring;
    do {
        update_finger_table_for_machine(current, identifier_space, start_of_ring);
        current = current->get_next_machine();
    } while (current != start_of_ring);
}

//now i think yahan mapped hash id ho gi
bool insert_machine_based_on_hash_id(Machine** head_pointer, Machine* new_node, int identifier_space)
{//newNode would have 
    if (search_machine(*head_pointer, new_node))
    {
        cout << "Invalid input! Machine already exists.\n";
        return 0;
    }
    machineCount++;
    Machine* current = *head_pointer;

    if (current == nullptr) //insert to head if empty
    {
        //new_node->SuccessorId = -1;//means no succesoor exists for only one machine
        new_node->set_next_machine(new_node);
        *head_pointer = new_node;
    }
    else if (current->get_hash_id() < new_node->get_hash_id()) //if new object's hash id is greater than head's hash id, use current->next to see if current->next->hash_id is greater than new object's, then insert before it
    {
        while ((current->get_next_machine() != *head_pointer) && (current->get_next_machine()->get_hash_id() < new_node->get_hash_id()))
        {
            current = current->get_next_machine();
        }

        new_node->set_next_machine(current->get_next_machine());
        // current->SuccessorId = new_node->mapped_ID_within_identifier_Space;//setting successorIds  of each machine node to determine ranges easily
        current->set_next_machine(new_node);

    }
    else if (current->get_hash_id() >= new_node->get_hash_id()) //if new object's hash id is less than head's hash id. insert after last node, and new obj points to head
    {
        while (current->get_next_machine() != *head_pointer)
        {
            current = current->get_next_machine();
        }

        //  current->SuccessorId= new_node->mapped_ID_within_identifier_Space;
        current->set_next_machine(new_node);
        new_node->set_next_machine(*head_pointer);

        *head_pointer = new_node;
    }
    //ab traverse the linked list and update kartey jao successorids ko c
    update_successor_and_predecessor_ids(*head_pointer);
    update_all_finger_tables(*head_pointer, identifier_space);
    // Call this function after all machines have been inserted and the ring is complete
  //  initialize_finger_table(start_of_ring, identifier_space);
    //NABZ
    cout << "Machine added successfully!\n";
    return 1;
}

void print_ring(Machine* start_of_ring, int identifier_space) {

    Machine* temp = start_of_ring;
    cout << "Printing Ring DHT Data:" << endl;
    do {
        cout << "\nMachine name: " << temp->get_machine_name();
        cout << "\nHash ID: " << temp->sha1_get_hash_id();
        cout << "\nMapped Hash ID: " << temp->mapped_ID_within_identifier_Space;
        cout << "\nSuccessor mapped ID: " << temp->SuccessorId;
        cout << "\nPredecessor mapped ID: " << temp->PredecessorId;
        cout << "\nFinger Table:\n";
        for (int i = 0; i < identifier_space; ++i)
        {
            cout << "\tEntry " << i << ": " << endl;
            cout << "\t\tFPi: " << temp->headOfFingerTable[i].FPi << endl;
            cout << "\t\tShortcut Pointer: " << (temp->headOfFingerTable[i].shortCutPtr ? temp->headOfFingerTable[i].shortCutPtr->get_hash_id() : -1) << endl;
        }

        temp = temp->get_next_machine();
        cout << endl;
    } while (temp != start_of_ring);
    cout << "\nRingDHT printed successfully\n";
}

//ABHI I NEED TO ADD THE LOGIC TO DISTRIBUTE FILES HERE TOO
void distributeData(Machine** start_of_ring, Machine* machineToDelete) {
    if (machineToDelete == nullptr || start_of_ring == nullptr || *start_of_ring == nullptr) {
        return;
    }

    Machine* successor = machineToDelete->get_next_machine();


    if (successor == machineToDelete) {
        return;
    }


    Machine* predecessor = *start_of_ring;
    while (predecessor->get_next_machine() != machineToDelete) {
        predecessor = predecessor->get_next_machine();
    }


    predecessor->SuccessorId = successor->mapped_ID_within_identifier_Space;


    predecessor->set_next_machine(successor);


    successor->PredecessorId = machineToDelete->PredecessorId;


    if (*start_of_ring == machineToDelete) {
        *start_of_ring = successor;
    }


    delete machineToDelete;
}

void deleteMachine(Machine** start_of_ring, const string& machine_name, int identifier_space) {
    if (*start_of_ring == nullptr) {
        cout << "Nothing to delete, RingDHT is empty.\n";
        return;
    }

    Machine* current = *start_of_ring;
    Machine* prev = nullptr;

    do {
        if (current->machinename == machine_name)
        {
            cout << "Machine to delete is found\n";
            break;
        }
        prev = (prev == nullptr) ? *start_of_ring : prev->get_next_machine();
        current = current->get_next_machine();
    } while (current != *start_of_ring);

    if (current->machinename != machine_name || (current == current->get_next_machine() && current->machinename == machine_name)) {
        if (current == current->get_next_machine()) {
            delete current;
            *start_of_ring = nullptr;
        }
        return;
    }

    if (current == *start_of_ring) {
        *start_of_ring = current->get_next_machine();
    }

    distributeData(start_of_ring, current);//this function basically recalculates the succesoor and predecessor ids after deletion of machine ..wo links sahi karta

    // Update the finger tables of all machines in the ring.
    update_all_finger_tables(*start_of_ring, identifier_space);

    cout << "Machine '" << machine_name << "' deleted successfully." << endl;
}

Machine* query_find(Machine* start_of_ring, int query, int identifier_space) {
    if (start_of_ring == nullptr) {
        cout << "The ring is empty." << endl;
        return nullptr;
    }
    Machine* current = start_of_ring;
    Machine* start = start_of_ring;
    cout << "-----> I am currently standing at machine: " << current->machinename << endl;

    while (true) {
        int prev_id = (current->PredecessorId != -1) ? current->PredecessorId : (1 << identifier_space) - 1;
        if ((prev_id < query && query <= current->mapped_ID_within_identifier_Space) ||
            (prev_id > current->mapped_ID_within_identifier_Space && (query > prev_id || query <= current->mapped_ID_within_identifier_Space)))
        {
            cout << "-----> I am returning at machine: " << current->machinename << endl;
            return current;
        }

        bool moved = false;
        for (int i = identifier_space - 1; i >= 0; i--) {
            Machine* next_hop = current->headOfFingerTable[i].shortCutPtr;
            if (next_hop == nullptr) {
                continue;
            }

            int next_hop_prev_id = (next_hop->PredecessorId != -1) ? next_hop->PredecessorId : (1 << identifier_space) - 1;
            if ((next_hop_prev_id < query && query <= next_hop->mapped_ID_within_identifier_Space) ||
                (next_hop_prev_id > next_hop->mapped_ID_within_identifier_Space && (query > next_hop_prev_id || query <= next_hop->mapped_ID_within_identifier_Space)))
            {
                current = next_hop;
                cout << "-----> I am jumping to machine: " << current->machinename << endl;
                moved = true;
                break;
            }
        }

        // move to the next machine in the ring if not in currents range and also no shortcut pointer found ...specific edge case as discussed in project doc
        if (!moved) {
            current = current->get_next_machine();
            cout << "Moving to next machine in the ring: " << current->machinename << endl;
            // If we have looped around the entire ring without finding the query ID, return nullptr
            if (current == start) {
                cout << "The query ID does not match any machine ID in the ring." << endl;
                return nullptr;
            }
        }
    }
}

void printFingerTableOfMachineByName(Machine* start_of_ring, const string& machineName, int identifier_space)
{
    if (start_of_ring == nullptr) {
        //cout << "The ring is empty." << endl;
        cout << "The RingDHT is empty.\n";
        return;
    }

    Machine* current = start_of_ring;
    bool found = false;

    // Search for the machine with the given name
    do {
        if (current->machinename == machineName) {
            found = true;
            break;
        }
        current = current->get_next_machine();
    } while (current != start_of_ring);

    if (found == false) {
        cout << "Machine with name '" << machineName << "' not found." << endl;
        return;
    }

    cout << "\nFinger Table of machine '" << machineName << "': \n";
    for (int i = 0; i < identifier_space; ++i)
    {
        cout << "\tEntry " << i << ": " << endl;
        cout << "\t\tFPi: " << current->headOfFingerTable[i].FPi << endl;
        cout << "\t\tShortcut Pointer: ";
        if (current->headOfFingerTable[i].shortCutPtr != nullptr)
        {
            cout << current->headOfFingerTable[i].shortCutPtr->machinename << endl;
        }
        else {
            cout << "No shortcut pointer found! :(" << endl;
        }
    }
}

void printFingerTableOfMachineByMappedHashID(Machine* start_of_ring, int mapped_hash_id, int identifier_space)
{
    if (start_of_ring == nullptr) {
        cout << "The RingDHT is empty.\n";
        return;
    }

    Machine* current = start_of_ring;
    bool found = false;

    // Search for the machine with the given name
    do {
        if (current->mapped_ID_within_identifier_Space == mapped_hash_id)
        {
            found = true;
            break;
        }
        current = current->get_next_machine();
    } while (current != start_of_ring);

    if (found == false) {
        cout << "Machine with mapped id: '" << mapped_hash_id << "' not found." << endl;
        return;
    }

    cout << "\nFinger Table of machine with mapped ID '" << mapped_hash_id << "': \n";
    for (int i = 0; i < identifier_space; ++i)
    {
        cout << "\tEntry " << i << ": " << endl;
        cout << "\t\tFPi: " << current->headOfFingerTable[i].FPi << endl;
        cout << "\t\tShortcut Pointer: ";
        if (current->headOfFingerTable[i].shortCutPtr != nullptr)
        {
            cout << current->headOfFingerTable[i].shortCutPtr->mapped_ID_within_identifier_Space << endl;
        }
        else {
            cout << "No shortcut pointer Found! :(" << endl;
        }
    }
}

void printFingerTableOfMachineByBigHashID(Machine* start_of_ring, const string& hashID, int identifier_space) {
    if (start_of_ring == nullptr) {
        cout << "The RingDHT is empty." << endl;
        return;
    }

    Machine* current = start_of_ring;
    bool found = false;

    // Search for the machine with the given hash ID
    do {
        if (current->m_hash_id == hashID) {
            found = true;
            break;
        }
        current = current->get_next_machine();
    } while (current != start_of_ring);

    if (found == false) {
        cout << "Machine with hash ID '" << hashID << "' not found." << endl;
        return;
    }

    cout << "\nFinger Table of machine with hash ID '" << hashID << "': \n";
    for (int i = 0; i < identifier_space; ++i)
    {
        cout << "\tEntry " << i << ": " << endl;
        cout << "\t\tFPi: " << current->headOfFingerTable[i].FPi << endl;
        cout << "\t\tShortcut Pointer: ";
        if (current->headOfFingerTable[i].shortCutPtr != nullptr)
        {
            cout << current->headOfFingerTable[i].shortCutPtr->m_hash_id << endl;
        }
        else
        {
            cout << "No Shortcut pointer found :(" << endl;
        }
    }
}

Machine* query_find_by_name(Machine* start, const string& machineName, int identifier_space)
{
    if (start == nullptr)
    {
        return nullptr;
    }

    Machine* current = start;
    do
    {
        if (current->machinename == machineName)
        {
            return current;
        }
        current = current->next_machine;
    } while (current != start);

    return nullptr;
}

Machine* Machine_Responsible_for_File_Mapped_Id(Machine* start_of_ring, int file_mapped_id, int identifier_space) {
    if (start_of_ring == nullptr) {

        return nullptr;
    }

    Machine* current = start_of_ring;
    do {

        int predecessor_id = (current->PredecessorId != -1) ? current->PredecessorId : (1 << identifier_space) - 1;

        // checking if the file's mapped ID falls within the current machine's range(exculsive of predecessor id and inclusive of it,s own mapped id]
        if ((predecessor_id < file_mapped_id && file_mapped_id <= current->mapped_ID_within_identifier_Space) ||
            (predecessor_id > current->mapped_ID_within_identifier_Space && (file_mapped_id > predecessor_id || file_mapped_id <= current->mapped_ID_within_identifier_Space)))
        {
            return current;
        }


        current = current->get_next_machine();
    } while (current != start_of_ring);

    cout << "No machine found that has the requested query!" << endl;
    return nullptr;
}

class User
{
private:
public:
    Machine* start_of_ring;
    int num_of_machines;
public:
    User()
    {
        start_of_ring = nullptr;
        num_of_machines = 0;
    }
    Machine& get_start_of_ring()
    {
        return *start_of_ring;
    }
    void menu()
    {
        int choice = 0;
        while (1)
        {
            cout << "\033[2J\033[1;1H";
            cout << white_colour << "\n----------------------------------------------\n";
            cout << light_blue_colour;
            cout << white_colour << "|" << light_blue_colour << "         _______                            " << white_colour << "|" << endl;
            cout << white_colour << "|" << light_blue_colour << "        |   |   |.-----.-----.--.--.        " << white_colour << "|" << endl;
            cout << white_colour << "|" << light_blue_colour << "        |       ||  -__|     |  |  |        " << white_colour << "|" << endl;
            cout << white_colour << "|" << light_blue_colour << "        |__|_|__||_____|__|__|_____|        " << white_colour << "|" << endl;
            cout << white_colour << "|                                            |";
            cout << "\n----------------------------------------------\n\n";
            cout << " 0. Check the identifier space set\n";
            cout << " 1. Number of machines in the system\n";
            cout << " 2. Add a file to the system\n";
            cout << " 3. Search for a file via Search Algorithm O(log n)\n"; 
            cout << " 4. Remove a file from the system\n" ; 
            cout << " 5. Print the list of files in a machine\n"; 
            cout << " 6. Print the list of files in the system\n";
            cout << " 7. Add a new machine to the system\n"; 
            cout << " 8. Search if a machine exists\n";
            cout << " 9. Remove a machine from the system by name\n";
            cout << "10. Print routing table of a machine by name\n";
            cout << "11. Print routing table of a machine by mapped id\n";
            cout << "12. Print routing table of a machine by sha1 id\n";
            cout << "13. Print all machines in the system\n";
            cout << "14. Exit program\n";
            cout << "----------------------------------------------\n";
            cout << "Your choice: ";
            
            choice = integer_input_validation(choice, 0, 14);
            cout << "----------------------------------------------\n";

            switch (choice)
            {
            case 0:
            {
                cout << "Identifier Space of system: " << identifier_space << endl;
                break;
            }
            case 1:
            {
                cout << "Number of machines in the system currently: " << num_of_machines << endl;
                break;
            }
            case 2:
            {
                cin.ignore();
                string name;
                cout << "Enter file name: ";
                getline(cin, name);
                string path;
                cout << "Enter file path: ";
                getline(cin, path);
                uint64_t hash_id = generateSHA1Hash1(path);
                string str_hash_id = generateSHA1Hash(path);
                int mapped_id = mapped_id_for_machine_generator_for_file(str_hash_id, identifier_space);
                cout << "File's SHA-1 string hash ID: " << str_hash_id << endl;
                cout << "File's SHA-1 uint64_t hash ID: " << hash_id << endl;
                cout << "File's mapped ID: " << mapped_id << endl;
                Machine* selected_machine = Machine_Responsible_for_File_Mapped_Id(start_of_ring, mapped_id, identifier_space);
                selected_machine->head_of_files->insert(hash_id, mapped_id, name, path);
                int m_id = selected_machine->mapped_ID_within_identifier_Space;

                string folder_path = "C:/Users/mahaq/OneDrive/Desktop/dsa/FinalProject/FinalProject/Machine #" + to_string(m_id);
                string source = path;
                string destination = folder_path + "/" + name;
                ofstream createfile(name, ios::app);
                createfile.close();
                if (!copyFile(source, destination))
                {
                    cout << "File does not exist." << endl;
                }
                else
                {
                    cout << "File copied into the folder.\n";
                }

                break;
            }
            case 3:
            {
                cin.ignore();
                string name;
                cout << "Enter file name: ";
                getline(cin, name);
                string path;
                cout << "Enter file path: ";
                getline(cin, path);
                uint64_t hash_id = generateSHA1Hash1(path);
                string str_hash_id = generateSHA1Hash(path);
                int mapped_id = mapped_id_for_machine_generator_for_file(str_hash_id, identifier_space);
                cout << "File's SHA-1 string hash ID: " << str_hash_id << endl;
                cout << "File's SHA-1 uint64_t hash ID: " << hash_id << endl;
                cout << "File's mapped ID: " << mapped_id << endl;
                Machine* selected_machine = query_find(start_of_ring, mapped_id, identifier_space);

                cout << "Printing the files of machine found:\n";
                selected_machine->head_of_files->traverse();

                cout << "Searching for our file within the BTree:\n";
                btreeNode* x = selected_machine->head_of_files->search(hash_id);
                if (x == nullptr)
                {
                    cout << "File not found.\n";
                }
                else
                {
                    cout << "File found.\n";
                    cout << "File's SHA-1 string hash ID: " << str_hash_id << endl;
                    cout << "File's SHA-1 uint64_t hash ID: " << hash_id << endl;
                    cout << "File's mapped ID: " << mapped_id << endl;
                    cout << "File name: " << x->get_name() << endl;
                    cout << "File path: " << x->get_path() << endl;
                }

                break;
            }
            case 4:
            {
                cin.ignore();
                string name;
                cout << "Enter file name: ";
                getline(cin, name);
                string path;
                cout << "Enter file path: ";
                getline(cin, path);
                uint64_t hash_id = generateSHA1Hash1(path);
                string str_hash_id = generateSHA1Hash(path);
                int mapped_id = mapped_id_for_machine_generator_for_file(str_hash_id, identifier_space);
                cout << "File's SHA-1 string hash ID: " << str_hash_id << endl;
                cout << "File's SHA-1 uint64_t hash ID: " << hash_id << endl;
                cout << "File's mapped ID: " << mapped_id << endl;
                Machine* selected_machine = Machine_Responsible_for_File_Mapped_Id(start_of_ring, mapped_id, identifier_space);
                selected_machine->head_of_files->remove(hash_id);
                int m_id = selected_machine->mapped_ID_within_identifier_Space;

                string folder_path = "C:/Users/mahaq/OneDrive/Desktop/dsa/FinalProject/FinalProject/Machine #" + to_string(m_id);
                string source = folder_path + "/" + name;

                if (remove(source.c_str()) != 0)
                {
                    cout << "File does not exist." << endl;
                }
                else
                {
                    cout << "File removed successfully!" << endl;
                }
                
                selected_machine->head_of_files->remove(hash_id); //remove from btree
                break;
            }
            case 5:
            {
                int m_id = 0;
                cout << "Enter mapped ID of machine: ";
                cin >> m_id;

                Machine* machine = Machine_Responsible_for_File_Mapped_Id(start_of_ring, m_id, identifier_space);

                if (machine != nullptr)
                {
                    cout << "Files:\n";
                    machine->head_of_files->traverse();
                }
                else
                {
                    cout << "Machine with ID " << m_id << " does not exist in the ring." << endl;
                }
                break;
            }
            case 6:
            {
                Machine* current = start_of_ring;
                do
                {
                    cout << "Machine #" << current->mapped_ID_within_identifier_Space << ": \n";
                    current->head_of_files->traverse();
                    current = current->next_machine;
                    cout << endl;
                } while (current != start_of_ring);
                break;
            }
            case 7:
            {
                if (num_of_machines == pow(2, identifier_space) - 1)
                {
                    cout << "Ring DHT is full. Machine not added.\n";
                    break;
                }
                cin.ignore();
                insert_to_ring();

                cout << endl;

                print_ring(start_of_ring, identifier_space);
                break;
            }
            case 8:
            {
                cin.ignore();
                Machine* temp = new Machine();
                temp = create_machine(start_of_ring);
                if (search_machine(start_of_ring, temp))
                {
                    cout << "Machine exists in the system.\n";
                }
                else
                {
                    cout << "Machine does not exist in the system.\n";
                }
                break;
            }
            case 9:
            {
                cout << "Enter machine name: ";
                string machine_name = "";
                machine_name = string_input_validation(machine_name);
                
                Machine* to_delete = query_find_by_name(start_of_ring, machine_name, identifier_space);
                if (to_delete != nullptr)
                {
                    string folder_path = "C:/Users/mahaq/OneDrive/Desktop/dsa/FinalProject/FinalProject/Machine #" + to_string(to_delete->mapped_ID_within_identifier_Space);
                   
                    if (to_delete->next_machine != nullptr)
                    {
                        to_delete->head_of_files->give_files_to_next_machine(to_delete->next_machine->mapped_ID_within_identifier_Space, to_delete->next_machine);
                        
                        cout << "Files copied to the next machine's folder." << endl;
                    }
                    else
                    {
                        cout << "No next machine in the RingDHT." << endl;
                    }

                    string command = "rmdir /s /q \"" + folder_path + "\""; //using this command will remove the folder

                    int result = system(command.c_str());

                    if (result == 0)
                    {
                        cout << "Folder deleted successfully!" << endl;
                    }
                    else
                    {
                        cout << "Folder not found." << endl;
                    }

                }
                else
                {
                    cout << "Machine not found." << endl;
                }

                deleteMachine(&start_of_ring, machine_name, identifier_space);

                num_of_machines--;
                break;
            }
            case 10:
            {
                cin.ignore();
                cout << "Enter machine name: ";
                string machine_name = "";
                getline(cin, machine_name);
                printFingerTableOfMachineByName(start_of_ring, machine_name, identifier_space);
                break;
            }
            case 11:
            {
                cout << "Enter machine's mapped id: ";
                int mapped_hash_id = 0;
                cin >> mapped_hash_id;
                printFingerTableOfMachineByMappedHashID(start_of_ring, mapped_hash_id, identifier_space);
                break;
            }
            case 12:
            {
                cin.ignore();
                cout << "Enter SHA-1 hash ID of machine: ";
                string machine_sha1 = "";
                getline(cin, machine_sha1);
                printFingerTableOfMachineByBigHashID(start_of_ring, machine_sha1, identifier_space);
                break;
            }
            case 13:
            {
                print_ring(start_of_ring, identifier_space);
                break;
            }
            case 14:
            {
                Machine* to_delete = start_of_ring;
                do
                {
                    string folder_path = "C:/Users/mahaq/OneDrive/Desktop/dsa/FinalProject/FinalProject/Machine #" + to_string(to_delete->mapped_ID_within_identifier_Space);
                    
                    string command = "rmdir /s /q \"" + folder_path + "\""; //using this command will remove the folder

                    int result = system(command.c_str());

                    if (result == 0)
                    {
                        cout << "Folder deleted successfully!" << endl;
                    }
                    else
                    {
                        cout << "Folder not found." << endl;
                    }
                    to_delete = to_delete->next_machine;
                } while (to_delete != start_of_ring);

                cout << "Terminating program...\n";
                exit(0);
            }
            }
            cout << endl;
            cout << ladoo_peela_colour;
            system("pause");
        }
    }
    void insert_to_ring()
    {
        Machine* temp = new Machine();
        temp = create_machine(start_of_ring);
        if (insert_machine_based_on_hash_id(&start_of_ring, temp, identifier_space))
        {
            num_of_machines++;
        }

        if (temp->next_machine != nullptr)
        {
            temp->next_machine->head_of_files->distribute_files(temp->next_machine, temp); //traverse thru next machine's btree na
        }

        cout << "Number of machines in the system now: " << num_of_machines << endl;
    }
};

int main()
{
    system("cls");
    User user;
    string machine_name = "", ipfs = "      _/_/_/   _/_/_/    _/_/_/_/    _/_/_/ \n       _/     _/    _/  _/        _/\n      _/     _/_/_/    _/_/_/      _/_/\n     _/     _/        _/              _/\n  _/_/_/   _/        _/        _/_/_/\n";
    int create_machines = 0, choice = 0;
    cout << white_colour;
    cout << "----------------------------------------------\n";
    cout << "Welcome to Inter Planetary File System (IPFS)!\n";
    cout << "----------------------------------------------\n\n\n\n\n\n";
    cout << white_colour;
    cout << "----------------------------------------------\n";
    cout << "      Let's create a File Sharing system!\n";
    cout << "----------------------------------------------\n";
    int x = 0, y = 3;
    cout << "\033[" << y + 1 << ";" << x + 1 << "H" << blue_colour;
    for (int i = 0; i < ipfs.length(); i++)
    {
        cout << ipfs[i];
        Sleep(30);
    }
    x = 0, y = 10;
    cout << "\033[" << y + 1 << ";" << x + 1 << "H" << white_colour;

    cout << "\n\nEnter identifier space: ";
    identifier_space = integer_input_validation(identifier_space, 1, 160);
    cout << "Enter order of BTree: ";
    order = integer_input_validation(order, 0, 20);
    
    cout << "Number of machines you want to enter right now: ";
    create_machines = integer_input_validation(create_machines, 1, pow(2, identifier_space) - 1);
    cin.ignore();

    for (int i = 0; i < create_machines; i++)
    {
        user.insert_to_ring();
        cout << endl;
        print_ring(user.start_of_ring, identifier_space);
        cout << endl;
    }
    user.menu();
}